package com.livegoods.comments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivegoodsCommentsApp {
    public static void main(String[] args) {
        SpringApplication.run(LivegoodsCommentsApp.class, args);
    }
}
