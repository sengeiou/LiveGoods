package com.livegoods.banner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivegoodsBannerApp {
    public static void main(String[] args) {
        SpringApplication.run(LivegoodsBannerApp.class, args);
    }
}
