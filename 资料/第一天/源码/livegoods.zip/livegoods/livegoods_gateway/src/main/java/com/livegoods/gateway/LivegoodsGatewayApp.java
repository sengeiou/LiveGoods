package com.livegoods.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivegoodsGatewayApp {
    public static void main(String[] args) {
        SpringApplication.run(LivegoodsGatewayApp.class, args);
    }
}
