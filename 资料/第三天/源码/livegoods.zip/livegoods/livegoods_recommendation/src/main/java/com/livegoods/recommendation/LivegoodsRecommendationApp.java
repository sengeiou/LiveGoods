package com.livegoods.recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivegoodsRecommendationApp {
    public static void main(String[] args) {
        SpringApplication.run(LivegoodsRecommendationApp.class, args);
    }
}
